/*************************************************************************
 * uload.h
 *   Instruction loading and parsing and routine.
 *************************************************************************/
#ifndef uLOAD_H
#define uLOAD_H

int uLoad(uINSTRUCTION code[], int label[]);

#endif /* uLOAD_H */
