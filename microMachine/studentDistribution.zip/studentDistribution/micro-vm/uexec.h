/*************************************************************************
 * uexec.h
 *   Program execution routine.
 *************************************************************************/
#ifndef uEXEC_H
#define uEXEC_H

int uExecute(uINSTRUCTION code[], int label[]);

#endif /* uEXEC_H */

